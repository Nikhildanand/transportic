import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy-component',
  templateUrl: './dummy-component.component.html',
  styleUrls: ['./dummy-component.component.scss']
})
export class DummyComponentComponent implements OnInit {

  constructor() { }

  label = 'dummy button label';

  ngOnInit(): void {
  }

}
